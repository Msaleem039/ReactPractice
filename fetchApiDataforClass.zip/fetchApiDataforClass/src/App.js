import './App.css';
import FetchUserData from './components/FetchUserData';
// import ProductCard from './components/ProductCard';

function App() {
  return (
    <div className="App">
        {/* <h1 style={{color: "red", backgroundColor: 'yellow', textDecoration: 'underline'}}>Fetch API in React JS</h1> */}
        {/* <ProductCard /> */}
        <FetchUserData />
    </div>
  );
}

export default App;

// styled components 
// tailwind css
// material ui




// http://localhost:3005/products 