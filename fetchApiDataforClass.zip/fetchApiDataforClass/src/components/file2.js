import React, { useEffect, useState } from 'react'

function FetchData() {

    const [prodata, setProData] = useState([]);
  

    useEffect(() => {
        const productsDetail = async() => {
            let result = await fetch('https://fakestoreapi.com/products');
            // let data = await result.json();
            result = await result.json();        
            setProData(data);
        }
        productsDetail();
    }, [])

    return (
        <>
            <h1>Fetch Data file</h1>

            {/* <button onClick={productsDetail}>Show Products</button> */}

            <div className='container'>
                <div className='row'>
            {
                prodata.map(elem => {
                    return (
                        <div key={elem.id} className='col-lg-4 col-md-4 col-12 g-4'>
                            <div className="card" style={{width: '16rem'}}>
                                <img src={elem.image} className="card-img-top" height={250} alt="..." />
                                    <div className="card-body">
                                        <h5 className="card-title">{elem.title.slice(0,20)}...</h5>
                                        <p className="card-text">{elem.description.slice(0,50)}..</p>
                                        <p className="card-text">{elem.price}</p>
                                        <a href="#" className="btn btn-primary">Buy</a>
                                    </div>
                            </div>
                        </div>
                    )
                })
            }
            </div>
            </div>
        </>
    )
}

export default FetchData;


// fetch api 
// you can do the following operations using fetch api 
    // data create 
    // data read 
    // data update 
    // data delete