import React, { useEffect, useState } from 'react'

function FetchData() {

    const [prodata, setProData] = useState([]);

    const productsDetail = () => {
        fetch('https://fakestoreapi.com/products')
            .then(res => res.json())
            .then(data => {
                setProData(data)
            })
    }
    // console.log(prodata)

    useEffect(() => {
        productsDetail();
    }, [])

    

    // useEffect(() => {
    //     const productsDetail = () => {
    //         fetch('https://fakestoreapi.com/products')
    //             .then(res => res.json())
    //             .then(data => {
    //                 setProData(data)
    //             })
    //     }
    //     productsDetail()
    // }, [])

    return (
        <>
            <h1>Fetch Data file</h1>
            <div className='container'>
                <div className='row'>
            {
                prodata.map(elem => {
                    return (
                        <div className='col-lg-4 col-md-4 col-12 g-4'>
                            <div className="card" style={{width: '16rem'}}>
                                <img src={elem.image} className="card-img-top" height={250} alt="..." />
                                    <div className="card-body">
                                        <h5 className="card-title">{elem.title.slice(0,20)}...</h5>
                                        <p className="card-text">{elem.description.slice(0,50)}..</p>
                                        <p className="card-text">{elem.price}</p>
                                        <a href="#" className="btn btn-primary">Buy</a>
                                    </div>
                            </div>
                        </div>
                    )
                })
            }
            </div>
            </div>
        </>
    )
}

export default FetchData;