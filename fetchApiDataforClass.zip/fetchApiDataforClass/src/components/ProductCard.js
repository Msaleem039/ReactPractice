// import React from 'react'
// import products from '../data/productsData';

// const ProductCard = () =>{
//     return(
//         <>
//             <h1>Products Card Detail</h1>
//             {
//                 products.map(prod =>{
//                     return(
//                         <>
//                             <h1>{prod.pname}</h1>
//                         </>
//                     )
//                 })
//             }
//         </>
//     )
// }

// export default ProductCard;