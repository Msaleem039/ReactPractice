import React, { useEffect, useState } from 'react'
import axios from 'axios'

function FetchUserData() {

    const [users, setUserse] = useState([]); 

    useEffect(() => {
        const userDetail = () => {
            axios.get('https://jsonplaceholder.typicode.com/users').then(res => setUserse(res.data))}
            userDetail();
    }, [])

    
    return (
        <>
            <h1>Fetch Users Data</h1>
            <div className='container'>
                <div className='row'>
            {
                users.map(elem => {
                    return (
                        <div className='col-lg-4 col-md-4 col-12 g-4'>
                            <div className="card" style={{width: '16rem'}}>
                                {/* <img src={elem.image} className="card-img-top" height={250} alt="..." /> */}
                                    <div className="card-body">
                                        <h5 className="card-title">{elem.name}</h5>
                                        <p className="card-text">{elem.website}</p>                                        
                                        <a href="#" className="btn btn-primary">Save</a>
                                    </div>
                            </div>
                        </div>
                    )
                })
            }
            </div>
            </div>
        </>
    )
}

export default FetchUserData;