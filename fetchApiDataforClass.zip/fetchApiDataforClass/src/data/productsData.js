let products = [
    {
        id: 1,
        pname: 'cloth 1',
        price: 7500,
        color: 'white',
        isOnSale: false
    },
    {
        id: 2,
        pname: 'cloth 21',
        price: 8000,
        color: 'pink',
        isOnSale: false
    },
]

export default products;

